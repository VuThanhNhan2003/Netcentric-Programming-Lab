package main

import (
	"fmt"
	"log"

	pb "Task1/proto"
    "google.golang.org/protobuf/proto"
)

func main() {
	// Create a Book
	book := &pb.Book{
		Id:            1,
		Title:         "The Great Gatsby",
		Author:        "F. Scott Fitzgerald",
		Isbn:          "9780743273565",
		Price:         10.99,
		Stock:         100,
		PublishedYear: 1925,
	}
	
	fmt.Printf("Book: %v\n", book)
	
	// Create DetailedBook with category and tags
	detailedBook := &pb.DetailedBook{
		Book:        *book,
		Category:    pb.BookCategory_FICTION,
		Description: "A novel set in the 1920s about the American dream.",
		Tags:        []string{"classic", "novel", "American"},
		Rating:      4.5,
	}
	
	fmt.Printf("\nDetailed Book: %v\n", detailedBook)
	fmt.Printf("Category: %s\n", detailedBook.Category)
	fmt.Printf("Tags: %v\n", detailedBook.Tags)
	
	// Serialize to bytes
	data, err := proto.Marshal(book)
	if err != nil {
		log.Fatal(err)
	}
	
	fmt.Printf("\nSerialized size: %d bytes\n", len(data))
	
	// Deserialize from bytes
	newBook := &pb.Book{}
	err = proto.Unmarshal(data, newBook)
	if err != nil {
		log.Fatal(err)
	}
	
	fmt.Printf("Deserialized book: %v\n", newBook)
	
	// Create Author with multiple books
	author := &pb.Author{
		Id:       1,
		Name:     "F. Scott Fitzgerald",
		Bio:      "An American novelist and short story writer.",
		BirthYear: 1896,
		Books:    []*pb.Book{book, newBook},
	}
	
	fmt.Printf("\nAuthor: %s\n", author.Name)
	fmt.Printf("Books written: %d\n", len(author.Books))
	for i, b := range author.Books {
		fmt.Printf("  %d. %s\n", i+1, b.Title)
	}
}