package main

import (
    "fmt"
    "math"
)

// Property struct holds real estate info
type Property struct {
    Name     string
    Price    float64
    Area     float64
    Bedrooms int
    District string
}

// Basic methods

func (p Property) PricePerM2() float64 {
    if p.Area == 0 {
        return 0
    }
    return p.Price / p.Area
}

func (p Property) IsAffordable(budget float64) bool {
    return p.Price <= budget
}

func formatPrice(price float64) string {
    if price >= 1000000000 {
        billions := price / 1000000000
        return fmt.Sprintf("%.1f tỷ VND", billions)
    }
    millions := price / 1000000
    return fmt.Sprintf("%.0f triệu VND", millions)
}

// --- Task 3.1: Investment Calculator ---

// Part 1: Calculate ROI
func (p Property) CalculateROI(monthlyRent float64) float64 {
    annualRent := monthlyRent * 12
    roi := (annualRent / p.Price) * 100
    return roi
}

// Part 2: Investment Grade based on ROI
func (p Property) InvestmentGradeWithRent(monthlyRent float64) string {
    roi := p.CalculateROI(monthlyRent)

    if roi > 8 {
        return "EXCELLENT"
    } else if roi >= 5 {
        return "GOOD"
    } else if roi >= 3 {
        return "FAIR"
    }
    return "POOR"
}

// Part 3: Find property with highest ROI
func findBestInvestment(properties []Property, rents []float64) (Property, float64) {
    bestProperty := properties[0]
    bestROI := properties[0].CalculateROI(rents[0])

    for i := 1; i < len(properties); i++ {
        roi := properties[i].CalculateROI(rents[i])
        if roi > bestROI {
            bestROI = roi
            bestProperty = properties[i]
        }
    }

    return bestProperty, bestROI
}

// --- Task 3.2: Loan Calculator ---

// Part 1: LoanInfo struct for loan details
type LoanInfo struct {
    LoanAmount     float64
    MonthlyPayment float64
    TotalInterest  float64
}

// Part 2: Calculate monthly mortgage payment
func calculateMonthlyPayment(loanAmount, annualRate float64, years int) float64 {
    monthlyRate := annualRate / 100 / 12
    numPayments := float64(years * 12)

    if annualRate == 0 {
        return loanAmount / numPayments
    }

    // Mortgage formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
    numerator := loanAmount * monthlyRate * math.Pow(1+monthlyRate, numPayments)
    denominator := math.Pow(1+monthlyRate, numPayments) - 1
    return numerator / denominator
}

// Part 3: Calculate full loan info for a property
func (p Property) CalculateLoan(downPaymentPercent, interestRate float64, years int) LoanInfo {
    downPayment := p.Price * (downPaymentPercent / 100)
    loanAmount := p.Price - downPayment

    monthlyPayment := calculateMonthlyPayment(loanAmount, interestRate, years)

    totalPaid := monthlyPayment * float64(years*12)
    totalInterest := totalPaid - loanAmount

    return LoanInfo{
        LoanAmount:     loanAmount,
        MonthlyPayment: monthlyPayment,
        TotalInterest:  totalInterest,
    }
}

// --- Main function ---

func main() {
    // Sample properties
    properties := []Property{
        {"Saigon Apartment", 2500000000, 75.5, 2, "District 1"},
        {"HCMC House", 4200000000, 120.0, 3, "District 7"},
        {"Budget Studio", 800000000, 35.0, 1, "Binh Thanh"},
    }

    // Monthly rents for each property
    monthlyRents := []float64{25000000, 35000000, 12000000}

    // TASK 3.1: Investment Analysis
    fmt.Println("=== Investment Analysis ===")
    for i, prop := range properties {
        roi := prop.CalculateROI(monthlyRents[i])
        grade := prop.InvestmentGradeWithRent(monthlyRents[i])
        fmt.Printf("%s: ROI %.1f%% per year - %s\n", prop.Name, roi, grade)
    }

    // Find best investment
    bestProp, bestROI := findBestInvestment(properties, monthlyRents)
    fmt.Printf("\nBest Investment: %s (%.1f%% ROI)\n", bestProp.Name, bestROI)

    // TASK 3.2: Loan Analysis
    fmt.Println("\n=== Loan Analysis ===")
    downPayment := 20.0 // 20%
    interestRate := 8.5 // 8.5%
    loanYears := 20     // 20 years

    for _, prop := range properties {
        loanInfo := prop.CalculateLoan(downPayment, interestRate, loanYears)

        fmt.Printf("%s:\n", prop.Name)
        fmt.Printf("  Loan Amount: %s (%.0f%% of price)\n",
            formatPrice(loanInfo.LoanAmount), 100-downPayment)
        fmt.Printf("  Monthly Payment: %s\n", formatPrice(loanInfo.MonthlyPayment))
        fmt.Printf("  Total Interest: %s over %d years\n\n",
            formatPrice(loanInfo.TotalInterest), loanYears)
    }
}
