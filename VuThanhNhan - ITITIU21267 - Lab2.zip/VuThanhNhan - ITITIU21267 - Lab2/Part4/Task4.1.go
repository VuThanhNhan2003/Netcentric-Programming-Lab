package main

import (
	"fmt"
	"time"
)

func searchEngineA(query string, ch chan string) {
	time.Sleep(300 * time.Millisecond) // Simulate search time
	result := fmt.Sprintf("Results from Engine A for '%s'", query)
	ch <- result
}

func searchEngineB(query string, ch chan string) {
	time.Sleep(200 * time.Millisecond) // Simulate search time
	result := fmt.Sprintf("Results from Engine B for '%s'", query)
	ch <- result
}

func main() {
	fmt.Println("=== Search Race ===")
	query := "golang concurrency"

	chA := make(chan string)
	chB := make(chan string)

	go searchEngineA(query, chA)
	go searchEngineB(query, chB)

	select {
	case resultA := <-chA:
		fmt.Println("Engine A won! (~300ms)")
		fmt.Println(resultA)
	case resultB := <-chB:
		fmt.Println("Engine B won! (~200ms)")
		fmt.Println(resultB)
	}
}
